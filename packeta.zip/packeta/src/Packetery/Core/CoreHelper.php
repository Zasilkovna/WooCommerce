<?php
/**
 * Class CoreHelper
 *
 * @package Packetery
 */

declare( strict_types=1 );

namespace Packetery\Core;

use DateTimeImmutable;

/**
 * Class CoreHelper
 *
 * @package Packetery
 */
class CoreHelper {
	public const TRACKING_URL          = 'https://tracking.packeta.com/?id=%s';
	public const MYSQL_DATETIME_FORMAT = 'Y-m-d H:i:s';
	public const MYSQL_DATE_FORMAT     = 'Y-m-d';
	public const DATEPICKER_FORMAT     = 'Y-m-d';
	public const DATEPICKER_FORMAT_JS  = 'yy-mm-dd';

	/**
	 * Simplifies weight.
	 *
	 * @param float|null $weight Weight.
	 *
	 * @return float|null
	 */
	public static function simplifyWeight( ?float $weight ): ?float {
		return self::simplifyFloat( $weight, 3 );
	}

	/**
	 * Simplifies float value to have max decimal places.
	 *
	 * @param float|null $value            Value.
	 * @param int        $maxDecimalPlaces Max decimal places.
	 *
	 * @return float|null
	 */
	public static function simplifyFloat( ?float $value, int $maxDecimalPlaces ): ?float {
		if ( null === $value ) {
			return null;
		}

		return (float) number_format( $value, $maxDecimalPlaces, '.', '' );
	}

	public static function trimDecimalPlaces( float $value, int $decimals ): string {
		$formattedValue = number_format( $value, $decimals, '.', '' );

		if ( $decimals > 0 ) {
			$valueWithoutTrailingZeros = rtrim( $formattedValue, '0' );

			return rtrim( $valueWithoutTrailingZeros, '.' );
		}

		return $formattedValue;
	}

	/**
	 * Returns tracking URL.
	 *
	 * @param string $packetId Packet ID.
	 *
	 * @return string
	 */
	public function get_tracking_url( string $packetId ): string {
		return sprintf( self::TRACKING_URL, rawurlencode( $packetId ) );
	}

	/**
	 * Creates UTC DateTime.
	 *
	 * @return DateTimeImmutable
	 * @throws \Exception From DateTimeImmutable.
	 */
	public static function now(): DateTimeImmutable {
		return new DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );
	}

	/**
	 * Creates string in given format from DateTimeImmutable object
	 *
	 * @param DateTimeImmutable|null $date   Datetime.
	 * @param string                 $format Datetime format.
	 *
	 * @return string|null
	 */
	public function getStringFromDateTime( ?DateTimeImmutable $date, string $format ): ?string {
		return null !== $date ? $date->format( $format ) : null;
	}

	/**
	 * Creates DateTimeImmutable object from string
	 *
	 * @param string $date Date.
	 *
	 * @return \DateTimeImmutable
	 * @throws \Exception From DateTimeImmutable.
	 */
	public function getDateTimeFromString( ?string $date ): ?DateTimeImmutable {
		return null !== $date ? new DateTimeImmutable( $date ) : null;
	}
}
